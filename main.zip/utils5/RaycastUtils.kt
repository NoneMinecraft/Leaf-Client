/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.utils5

import net.ccbluex.liquidbounce.utils5.RotationUtils.getVectorForRotation
import net.ccbluex.liquidbounce.utils5.RotationUtils.serverRotation
import net.ccbluex.liquidbounce.utils5.extensions.eyes
import net.ccbluex.liquidbounce.utils5.extensions.hitBox
import net.minecraft.entity.Entity
import net.minecraft.entity.player.EntityPlayer

object RaycastUtils : MinecraftInstance() {

    @JvmStatic
    @JvmOverloads
    fun raycastEntity(
        range: Double,
        yaw: Float = serverRotation.yaw,
        pitch: Float = serverRotation.pitch,
        entityFilter: (Entity) -> Boolean
    ): Entity? {
        val renderViewEntity = mc.renderViewEntity

        if (renderViewEntity != null && mc.theWorld != null) {
            var blockReachDistance = range
            val eyePosition = renderViewEntity.eyes
            val entityLook = getVectorForRotation(Rotation(yaw, pitch))
            val vec = eyePosition.addVector(
                entityLook.xCoord * blockReachDistance,
                entityLook.yCoord * blockReachDistance,
                entityLook.zCoord * blockReachDistance
            )

            val entityList = mc.theWorld.getEntitiesInAABBexcluding(
                renderViewEntity, renderViewEntity.entityBoundingBox.addCoord(
                    entityLook.xCoord * blockReachDistance,
                    entityLook.yCoord * blockReachDistance,
                    entityLook.zCoord * blockReachDistance
                ).expand(1.0, 1.0, 1.0)
            ) {
                it != null && (it !is EntityPlayer || !it.isSpectator) && it.canBeCollidedWith()
            }

            var pointedEntity: Entity? = null

            for (entity in entityList) {
                if (!entityFilter(entity)) continue

                val checkEntity = {
                    val axisAlignedBB = entity.hitBox

                    val movingObjectPosition = axisAlignedBB.calculateIntercept(eyePosition, vec)

                    if (axisAlignedBB.isVecInside(eyePosition)) {
                        if (blockReachDistance >= 0.0) {
                            pointedEntity = entity
                            blockReachDistance = 0.0
                        }
                    } else if (movingObjectPosition != null) {
                        val eyeDistance = eyePosition.distanceTo(movingObjectPosition.hitVec)

                        if (eyeDistance < blockReachDistance || blockReachDistance == 0.0) {
                            if (entity == renderViewEntity.ridingEntity && !renderViewEntity.canRiderInteract()) {
                                if (blockReachDistance == 0.0) pointedEntity = entity
                            } else {
                                pointedEntity = entity
                                blockReachDistance = eyeDistance
                            }
                        }
                    }

                    false
                }

                // Check newest entity first
                checkEntity()

            }

            return pointedEntity
        }

        return null
    }
}