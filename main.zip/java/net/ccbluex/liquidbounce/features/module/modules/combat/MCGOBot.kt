package net.ccbluex.liquidbounce.features.module.modules.combat

import akka.util.Switch
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.timer.TimerUtil
import net.ccbluex.liquidbounce.utils4.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.init.Items
import net.minecraft.item.Item
import net.minecraft.util.AxisAlignedBB
import net.minecraft.util.MathHelper
import net.minecraft.util.MovingObjectPosition
import net.minecraft.util.Vec3
import scala.annotation.switch
import javax.annotation.meta.When
import kotlin.math.atan2

@ModuleInfo(name = "MCGOBot", category = ModuleCategory.COMBAT)
class MCGOBot : Module() {

    var stackSize: Int = 0
    var lastStackSize: Int = -1
    var shotTick: Int = 0
    var offsetPitch: Double = -1.0
    private val timer: TimerUtil = TimerUtil()
    private val pitchOffset = FloatValue("PitchOffset", 0F, -5F, 5F)
    private val amount = IntegerValue("amount", 0, -5, 5)
    private val predictsize = FloatValue("PredictSize", 0F, 0F, 10F)
    private val Clicktick = IntegerValue("ClickTick", 0, 0, 20)
    private val ClickNoForward = BoolValue("ClickNoForward", false)
    private val antiYawOffset = BoolValue("AntiYawOffset", false)
    private val antiYawOffsetValue = IntegerValue("AntiYawOffsetValue", 2, -5, 5)
    private val AutoTick = BoolValue("AutoTick", true)
    private val AntiAim = BoolValue("AntiAim", true)
    private val EStop = BoolValue("EStopHelper", true)
    private val rotateValue = BoolValue("SilentRotate", true)
    private var targetPlayer: EntityPlayer? = null
    private var autotick = 0
    private var tick = 0
    private var autooffset = 0
    private var attack = false
    private var rangeoffset = 0
    private var es = false
    private var yaw = 0
    private var aa = true

    var predictedPositions: List<AxisAlignedBB> = ArrayList()
    var predictedPosition: Vec3? = null

    var ticks = 0
    var lastHeldItemCount = 0

    var cancelrun = false
    var Pitchpffset = 0
    override fun onDisable() {
        resetValues()
        ticks = 0
        lastHeldItemCount = 0
        cancelrun = false
        Pitchpffset = 0
        shotTick = 0
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {


        val player = mc.thePlayer ?: return
        val heldItem = player.inventory.getCurrentItem()
        val currentHeldItemCount = heldItem?.stackSize ?: 0

       if (targetPlayer == null){
           mc.gameSettings.keyBindUseItem.pressed = false
           ticks = 0
       }

        // 反运动偏移
        yaw = if (antiYawOffset.get()) {
            when {
                mc.gameSettings.keyBindLeft.pressed -> antiYawOffsetValue.get()
                mc.gameSettings.keyBindRight.pressed -> -antiYawOffsetValue.get()
                else -> 0
            }
        } else {
            0
        }
        //AA
        if (AntiAim.get()&&targetPlayer == null){
            RotationUtils.setTargetRotation(Rotation(mc.thePlayer.rotationYaw, 90F))

        }


        // 寻找目标玩家
        targetPlayer = mc.theWorld.playerEntities
            .filterIsInstance<EntityPlayer>()
            .filter { it != player && EntityUtils.isSelected(it, true) }
            .filter { it.getDistanceToEntityBox(player) <= 100 }
            .firstOrNull { canSeePlayer(player, it) }
        val speed = targetPlayer?.let {
            val motionX = it.motionX
            val motionY = it.motionY
            val motionZ = it.motionZ
            Math.sqrt(motionX * motionX + motionY * motionY + motionZ * motionZ)
        } ?: 0.0
        targetPlayer?.let {


            val targetVec = Vec3(it.posX+(it.posX - it.prevPosX) * predictsize.get(),
                (it.posY + it.eyeHeight*0.8)+it.posY-it.prevPosY,
                it.posZ+(it.posZ-it.prevPosZ)*predictsize.get())
            val playerVec = Vec3(player.posX, player.posY + player.eyeHeight, player.posZ)
            val rotation = getRotationTo(playerVec, targetVec)
            val Yaw = rotation.yaw



            if (ticks > 7)ticks=7
            if (mc.thePlayer.heldItem.item == Items.iron_hoe||mc.thePlayer.heldItem.item == Items.stone_hoe){
                if(currentHeldItemCount != lastHeldItemCount) {
                    shotTick++
                    lastHeldItemCount = currentHeldItemCount
                }else if (ticks <= 30){
                    ticks ++
                }else{
                    ticks = 0
                    shotTick = 0
                    lastHeldItemCount = currentHeldItemCount
                }
            }

           when(shotTick){
               0 -> {
                   offsetPitch = 0.0
                   offsetPitch = 3.3
               }

               1 -> offsetPitch = 3.3
               2 -> offsetPitch = 4.4
               3 -> offsetPitch = 5.5
               4 -> offsetPitch = 6.6
               5 -> offsetPitch = 7.0
               6 -> offsetPitch = 7.7
               7 -> offsetPitch = 8.8
               24 -> {offsetPitch = 8.8
                   shotTick = 0
               }
           }

            val Pitch  = rotation.pitch + (shotTick * 1.1F)


            if (rotateValue.get()) {
                RotationUtils.setTargetRotation(Rotation(Yaw, Pitch))
            } else {
                mc.thePlayer.rotationYaw = Yaw
                mc.thePlayer.rotationPitch = Pitch
            }
            // 急停功能
            if (EStop.get() && mc.gameSettings.keyBindLeft.pressed && mc.gameSettings.keyBindRight.pressed) {
                mc.gameSettings.keyBindLeft.pressed = false
                mc.gameSettings.keyBindRight.pressed = false
                mc.thePlayer.motionX = 0.0
                mc.thePlayer.motionZ = 0.0
                es = true
            } else {
                es = false
            }


            // 执行攻击操作
            if (!ClickNoForward.get() || !mc.gameSettings.keyBindForward.pressed) {
                if (mc.thePlayer.heldItem?.item !in listOf(Items.iron_axe, Items.stone_axe)) {
                    if (tick < Clicktick.get() + autotick) {
                        tick++
                        mc.gameSettings.keyBindUseItem.pressed = false
                        attack = false
                    } else {
                        mc.gameSettings.keyBindUseItem.pressed = true
                        attack = true
                        tick = 0
                    }
                }
            } else {
                attack = false
            }

        }
    }


    private fun resetValues() {
        autooffset = 0
        autotick = 0
        tick = 0
        attack = false
        rangeoffset = 0
        es = false
        yaw = 0
        aa = true

    }
    fun reset() {
        lastStackSize = -1
        offsetPitch = 0.0
        timer.reset()
        shotTick = 0
    }
    private fun canSeePlayer(player: EntityPlayer, target: EntityPlayer): Boolean {
        val world = mc.theWorld
        val playerVec = Vec3(player.posX, player.posY + player.eyeHeight, player.posZ)
        val targetVec = Vec3(target.posX, target.posY + target.eyeHeight, target.posZ)
        val result = world.rayTraceBlocks(playerVec, targetVec, false, true, false)
        return result == null || result.typeOfHit == MovingObjectPosition.MovingObjectType.MISS
    }

    private fun getRotationTo(from: Vec3, to: Vec3): Rotation {
        val diffX = to.xCoord - from.xCoord
        val diffY = to.yCoord - from.yCoord
        val diffZ = to.zCoord - from.zCoord
        val dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ)
        val yaw = (MathHelper.atan2(diffZ, diffX) * 180.0 / Math.PI).toFloat() - 90.0f
        val pitch = -(MathHelper.atan2(diffY, dist.toDouble()) * 180.0 / Math.PI).toFloat()
        return Rotation(yaw, pitch)
    }
    private fun getPrediction(target: EntityPlayer, ticks: Int) {
        val velocityX = target.posX - target.prevPosX
        val velocityY = target.posY - target.prevPosY
        val velocityZ = target.posZ - target.prevPosZ

        // Predict the future position
        val futurePosX = target.posX + (velocityX + target.motionX) * ticks
        val futurePosY = target.posY + (velocityY + target.motionY) * ticks
        val futurePosZ = target.posZ + (velocityZ + target.motionZ) * ticks
        predictedPosition = Vec3(futurePosX, target.posY + target.getEyeHeight(), futurePosZ)
    }
    fun handleShot(amount: Int, item: Item) {
        stackSize = amount
        if (lastStackSize == -1) lastStackSize = amount
        else if (stackSize != lastStackSize) {
            shotTick++
            timer.reset()
            lastStackSize = amount
        }

        if (timer.hasTimeElapsed(1500L)) {
            println("true")
            lastStackSize = amount
            shotTick = 0
            timer.reset()
        }


        if (item === Items.stone_shovel) {
            handleMP7(shotTick)
        }
    }
    private fun handleMP7(shotTicks: Int) {
        when (shotTicks) {
            0 -> offsetPitch = 0.0
            2 -> offsetPitch = 1.5
            4 -> offsetPitch = 3.0
            6 -> offsetPitch = 4.5
            8 -> offsetPitch = 6.0
            10 -> offsetPitch = 7.5
            12 -> offsetPitch = 9.0
            14 -> offsetPitch = 10.5
            16 -> offsetPitch = 12.0
        }
    }

    private fun getPlayerRotations(entity: EntityPlayer): Rotation {
        val xDelta = entity.posX - entity.lastTickPosX
        val zDelta = entity.posZ - entity.lastTickPosZ
        val yDelta = entity.posY - entity.lastTickPosY
        var d = mc.thePlayer.getDistanceToEntity(entity).toDouble()
        d -= d % 0.8
        var xMulti = 1.0
        var zMulti = 1.0
        val sprint = entity.isSprinting
        if (sprint){
        xMulti = d / 0.8 * xDelta
        zMulti = d / 0.8 * zDelta
        }
        val yMulti = d / 0.8 * yDelta * 0.1
        val x = entity.posX + xMulti - mc.thePlayer.posX
        val z = entity.posZ + zMulti - mc.thePlayer.posZ
        val y = mc.thePlayer.posY + mc.thePlayer.getEyeHeight().toDouble() - (entity.posY + entity.getEyeHeight()
            .toDouble()) - yMulti
        val dist = mc.thePlayer.getDistanceToEntity(entity).toDouble()
        val yaw = Math.toDegrees(atan2(z, x)).toFloat() - 90.0f
        val pitch = Math.toDegrees(atan2(y, dist)).toFloat()
        return Rotation(yaw, pitch)
    }
}
