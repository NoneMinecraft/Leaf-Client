package net.ccbluex.liquidbounce.event5;

public enum EventType {
    PRE,
    POST
}
