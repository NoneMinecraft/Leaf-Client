package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.MainLib.ChatPrint
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.gui.Gui
import net.minecraft.client.gui.GuiMainMenu
import net.minecraft.client.gui.inventory.GuiChest
import net.minecraft.init.Items
import net.minecraft.inventory.Slot
import net.minecraft.item.Item
import net.minecraft.item.ItemStack
import net.minecraft.network.play.server.S02PacketChat
import net.minecraft.util.ResourceLocation
import java.awt.Robot
import java.awt.event.InputEvent
import java.awt.event.KeyEvent
import kotlin.random.Random

@ModuleInfo(name = "AutoLeave", category = ModuleCategory.COMBAT)
object AutoLeave : Module() {
    private val Tick = IntegerValue("Tick",100,-1,2000)
    private val Tick2 = IntegerValue("Tick2",100,-1,2000)
    var tick = 0

    val robot = Robot()
    override fun onDisable() {
        tick = 0
    }


    @EventTarget
    fun UpdateEvent(event: UpdateEvent) {
        val screen = mc.currentScreen

        if (mc.thePlayer.inventory.getCurrentItem()?.item?.unlocalizedName == "item.compass") {
            mc.gameSettings.keyBindUseItem.pressed = false
        }
        if (screen !is GuiChest) {

            mc.thePlayer.inventory.currentItem = 1

            if (mc.thePlayer.inventory.getCurrentItem()?.item?.unlocalizedName != "item.compass") {
                Thread.sleep(5)
                mc.gameSettings.keyBindUseItem.pressed = true
            }
        }


        if (screen !is GuiChest){
        return
        }
        val items = mutableListOf<Slot>()
        for (slotIndex in 0 until screen.inventoryRows * 9) {
            val slot = screen.inventorySlots.inventorySlots[slotIndex]
            if (slot.stack != null && slot.stack.item == Items.iron_sword) {
                items.add(slot) } }
        val randomSlot = Random.nextInt(items.size)
        val slot = items[randomSlot]
        if (tick < Tick2.get()){
            tick++
        move(screen, slot)
            ChatPrint("n")
        }else if (tick < Tick.get()){
            tick ++
        }else{
            tick=0
        }
        }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is S02PacketChat) {
            val message = packet.chatComponent.unformattedText
            if (message.contains("找到对手: N0ne")) {
                mc.theWorld.sendQuittingDisconnectingPacket()
                tick = 0
            }
        }
        }
    private fun move(screen: GuiChest, slot: Slot) {
        screen.handleMouseClick(slot, slot.slotNumber, 0, 1)
    }
}