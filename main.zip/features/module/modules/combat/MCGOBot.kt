package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils4.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.Minecraft
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.init.Items
import net.minecraft.util.MathHelper
import net.minecraft.util.MovingObjectPosition
import net.minecraft.util.Vec3

@ModuleInfo(name = "MCGOBot", category = ModuleCategory.COMBAT)
class MCGOBot : Module() {
    private val pitchOffset = FloatValue("PitchOffset", 0F, -5F, 5F)
    private val Clicktick = IntegerValue("ClickTick", 0, 0, 20)
    private val ClickNoForward = BoolValue("ClickNoForward", false)
    private val antiYawOffset = BoolValue("AntiYawOffset", false)
    private val antiYawOffsetValue = IntegerValue("AntiYawOffsetValue", 2, -5, 5)
    private val AutoTick = BoolValue("AutoTick", true)
    private val EStop = BoolValue("EStopHelper", true)

    private var targetPlayer: EntityPlayer? = null
    private var autotick = 0
    private var tick = 0
    private var autooffset = 0
    private var attack = false
    private var rangeoffset = 0
    private var es = false
    private var yaw = 0

    override fun onDisable() {
        resetValues()
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val player = mc.thePlayer ?: return

        // 反运动偏移
        yaw = if (antiYawOffset.get()) {
            when {
                mc.gameSettings.keyBindLeft.pressed -> antiYawOffsetValue.get()
                mc.gameSettings.keyBindRight.pressed -> -antiYawOffsetValue.get()
                else -> 0
            }
        } else {
            0
        }

        // 自动判断武器偏移和自动点击间隔
        autooffset = when (mc.thePlayer.heldItem?.item) {
            Items.stone_hoe -> {
                if (AutoTick.get()) autotick = 1
                5
            }
            Items.diamond_shovel -> {
                autooffset = 6
                if (AutoTick.get()) autotick = 20
                6
            }
            Items.golden_hoe -> 1
            Items.stone_axe, Items.iron_axe -> 0
            Items.iron_hoe -> {
                if (AutoTick.get()) autotick = 1
                4
            }
            Items.stone_shovel -> {
                autooffset = 3
                if (AutoTick.get()) autotick = 5
                3
            }
            Items.wooden_pickaxe -> {
                autooffset = 2
                if (AutoTick.get()) autotick = 15
                2
            }
            else -> 0
        }

        // 寻找目标玩家
        targetPlayer = mc.theWorld.playerEntities
            .filterIsInstance<EntityPlayer>()
            .filter { it != player && EntityUtils.isSelected(it, true) }
            .filter { it.getDistanceToEntityBox(player) <= 100 }
            .firstOrNull { canSeePlayer(player, it) }

        // 如果有目标玩家，瞄准和攻击操作
        targetPlayer?.let {
            val targetVec = Vec3(it.posX, it.posY + it.eyeHeight, it.posZ)
            val playerVec = Vec3(player.posX, player.posY + player.eyeHeight, player.posZ)
            val rotation = getRotationTo(playerVec, targetVec)

            player.rotationYaw = rotation.yaw + yaw
            player.rotationPitch = rotation.pitch + pitchOffset.get() + autooffset + rangeoffset

            // 急停功能
            if (EStop.get() && mc.gameSettings.keyBindLeft.pressed && mc.gameSettings.keyBindRight.pressed) {
                mc.gameSettings.keyBindLeft.pressed = false
                mc.gameSettings.keyBindRight.pressed = false
                mc.thePlayer.motionX = 0.0
                mc.thePlayer.motionZ = 0.0
                es = true
            } else {
                es = false
            }

            // 执行攻击操作
            if (!ClickNoForward.get() || !mc.gameSettings.keyBindForward.pressed) {
                if (mc.thePlayer.heldItem?.item !in listOf(Items.iron_axe, Items.stone_axe)) {
                    if (tick < Clicktick.get() + autotick) {
                        tick++
                        mc.gameSettings.keyBindUseItem.pressed = false
                        attack = false
                    } else {
                        mc.gameSettings.keyBindUseItem.pressed = true
                        attack = true
                        tick = 0
                    }
                }
            } else {
                attack = false
            }

            // 根据距离调整攻击范围偏移量
            rangeoffset = when (it.getDistanceToEntityBox(player)) {
                in 0.1..5.0 -> 10
                in 5.1..10.0 -> 5
                else -> 0
            }
        } ?: run {
            mc.gameSettings.keyBindUseItem.pressed = false
            attack = false
        }
    }

    override val tag: String
        get() = "AutoOffset - $autooffset AutoTick - $autotick Attack - $attack EStop - $es"

    private fun resetValues() {
        autooffset = 0
        autotick = 0
        tick = 0
        attack = false
        rangeoffset = 0
        es = false
        yaw = 0
    }

    private fun canSeePlayer(player: EntityPlayer, target: EntityPlayer): Boolean {
        val world = mc.theWorld
        val playerVec = Vec3(player.posX, player.posY + player.eyeHeight, player.posZ)
        val targetVec = Vec3(target.posX, target.posY + target.eyeHeight, target.posZ)
        val result = world.rayTraceBlocks(playerVec, targetVec, false, true, false)
        return result == null || result.typeOfHit == MovingObjectPosition.MovingObjectType.MISS
    }

    private fun getRotationTo(from: Vec3, to: Vec3): Rotation {
        val diffX = to.xCoord - from.xCoord
        val diffY = to.yCoord - from.yCoord
        val diffZ = to.zCoord - from.zCoord
        val dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ)
        val yaw = (MathHelper.atan2(diffZ, diffX) * 180.0 / Math.PI).toFloat() - 90.0f
        val pitch = -(MathHelper.atan2(diffY, dist.toDouble()) * 180.0 / Math.PI).toFloat()
        return Rotation(yaw, pitch)
    }
}
