package net.ccbluex.liquidbounce.features.module.modules.combat.criticals.ncp

import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.features.module.modules.combat.criticals.CriticalMode
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition

class Ult : CriticalMode("Ult") {
    override fun onAttack(event: AttackEvent) {
        mc.thePlayer.sendQueue.addToSendQueue(C04PacketPlayerPosition(0.0, 2.43192168e-14, 0.0, true))
        mc.thePlayer.sendQueue.addToSendQueue(C04PacketPlayerPosition(0.0, -1.265e-256, 0.0, false))
    }
}