package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.EnumAutoDisableType
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClassUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.entity.EntityLivingBase
import net.minecraft.item.ItemStack
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import net.minecraft.network.play.client.C0EPacketClickWindow
import net.minecraft.network.play.client.C10PacketCreativeInventoryAction
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import net.minecraft.network.play.server.S0BPacketAnimation

@ModuleInfo(name = "Criticals", category = ModuleCategory.COMBAT, autoDisable = EnumAutoDisableType.FLAG)
class Criticals : Module() {
    private val Mode = ListValue("Mode", arrayOf("C04", "Motion","LegitJump","FastMotion"), "C04")
    private val MotionValue = FloatValue("MotionValue",0.1F,0.01F,0.42F)

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        when(Mode.get()){
            "FastMotion" ->{
                if (mc.thePlayer.hurtTime.toDouble() in 7.0..10.0){
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.motionY = 0.3
                    }
            }else if (mc.thePlayer.hurtTime.toDouble() in 0.0..6.999){
                    mc.thePlayer.motionY = -0.42
            }
            }
        }
    }
    @EventTarget
    fun onAttack(event: AttackEvent) {
        when(Mode.get()){
            "C04" -> {
                mc.thePlayer.sendQueue.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY+2.43192168e-14, mc.thePlayer.posZ, true))
                mc.thePlayer.sendQueue.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY-1.265e-256, mc.thePlayer.posZ, false))
            }
            "Motion" -> {
                if(mc.thePlayer.onGround) {
                    mc.thePlayer.motionY = MotionValue.get().toDouble()
                }
            }
            "LegitJump" ->{
                mc.gameSettings.keyBindJump.pressed = true
            }
        }
    }override val tag: String
        get() = Mode.get()
}
