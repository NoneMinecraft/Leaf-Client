package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.C02PacketUseEntity
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C09PacketHeldItemChange

@ModuleInfo(name = "ArmorBreak", category = ModuleCategory.COMBAT)
class ArmorBreak : Module() {
    private val mode = ListValue ("Mode", arrayOf("C04","C09","C02","Switch"),"C04")
    private val Slot = IntegerValue("Slot",0,0,8)
    private val Slot2 = IntegerValue("Slot2",1,0,8)
    var switchType = 0
    var switchTick = 0

    override fun onDisable() {
        switchType = 0
        switchTick = 0
    }

    @EventTarget
    fun AttackEvent(event: AttackEvent) {
        val targetEntity = event.targetEntity
        if (mode.get() == "C04"){
            mc.thePlayer.sendQueue.addToSendQueue(
                C03PacketPlayer.C04PacketPlayerPosition(
                    mc.thePlayer.posX,
                    mc.thePlayer.posY + 2.43192168e-14,
                    mc.thePlayer.posZ,
                    true
                )
            )
            mc.thePlayer.sendQueue.addToSendQueue(
                C03PacketPlayer.C04PacketPlayerPosition(
                    mc.thePlayer.posX,
                    mc.thePlayer.posY - 1.265e-256,
                    mc.thePlayer.posZ,
                    false
                )
            )
        }
        if (mode.get() == "Switch"){
            when (switchType) {
                0 -> {
                    if (switchTick < 4) {
                        mc.thePlayer.inventory.currentItem = Slot.get()
                        switchTick ++
                    }else{
                        switchType = 1
                        switchTick = 0
                    }
                }
                1 -> {
                    if (switchTick < 4) {
                        mc.thePlayer.inventory.currentItem = Slot2.get()
                        switchTick ++
                    }else {
                        switchType = 0
                        switchTick = 0
                    }
                }
            }
        }
        if (mode.get() == "C09"){
            when (switchType) {
                0 -> {
                    if (switchTick < 4) {
                        mc.thePlayer.sendQueue.addToSendQueue(C09PacketHeldItemChange(Slot.get()))
                        switchTick ++
                    }else{
                        switchType = 1
                        switchTick = 0
                    }
                }
                1 -> {
                    if (switchTick < 4) {
                        mc.thePlayer.sendQueue.addToSendQueue(C09PacketHeldItemChange(Slot2.get()))
                        switchTick ++
                    }else {
                        switchType = 0
                        switchTick = 0
                    }
                }
            }
        }
        if (mode.get() == "C02"){
            if (mc.thePlayer.onGround){
                mc.thePlayer.motionY = 0.42
            }else{
                mc.netHandler.addToSendQueue(
                    C02PacketUseEntity(
                    targetEntity,
                    C02PacketUseEntity.Action.ATTACK
                ))
            }
        }
    }override val tag: String
        get() = mode.get()
}
