package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.ListValue
import net.ccbluex.liquidbounce.value.TextValue
import net.minecraft.network.play.client.C01PacketChatMessage
import net.minecraft.network.play.server.S02PacketChat

@ModuleInfo(name = "Chat", category = ModuleCategory.COMBAT)
object Chat : Module() {
    private val modeValue = ListValue("Mode", arrayOf("HypeSw","HypeFirst","HypeSecond","HypeThird","HypeALL","Custom"), "HypeSw")
    private val messagev = TextValue("message","message")
    private val searchString = TextValue("SearchString","игрок - ").displayable{modeValue.get()=="Custom"}
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        val playerName = mc.thePlayer.name
        if (packet is S02PacketChat) {
            val message = packet.chatComponent.unformattedText
            if (modeValue.get()=="HypeSw" && message.contains("игрок - $playerName")) {
               mc.thePlayer.sendQueue.addToSendQueue(C01PacketChatMessage(messagev.get()))
            }
            if (modeValue.get()=="Custom" &&message.contains(searchString.get())) {
                mc.thePlayer.sendQueue.addToSendQueue(C01PacketChatMessage(messagev.get()))
            }
            if (modeValue.get()=="HypeFirst" && message.contains("#1 - $playerName")) {
                mc.thePlayer.sendQueue.addToSendQueue(C01PacketChatMessage(messagev.get()))
            }
            if (modeValue.get()=="HypeSecond" && message.contains("#2 - $playerName")) {
                mc.thePlayer.sendQueue.addToSendQueue(C01PacketChatMessage(messagev.get()))
            }
            if (modeValue.get()=="HypeThird" && message.contains("#3 - $playerName")) {
                mc.thePlayer.sendQueue.addToSendQueue(C01PacketChatMessage(messagev.get()))
            }
            if (modeValue.get()=="HypeALL" && message.contains(" - $playerName")) {
                mc.thePlayer.sendQueue.addToSendQueue(C01PacketChatMessage(messagev.get()))

            }
        }
}
    override val tag: String
        get() = modeValue.get()}
