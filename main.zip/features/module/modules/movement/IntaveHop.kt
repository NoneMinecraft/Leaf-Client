package net.ccbluex.liquidbounce.features.module.modules.movement
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.client.Minecraft
import net.minecraft.client.settings.KeyBinding
import net.minecraft.network.play.client.*
import net.minecraft.network.Packet
import net.minecraft.util.ChatComponentText

@ModuleInfo(name = "IntaveHop", category = ModuleCategory.MOVEMENT)
class IntaveHop : Module() {
    private val speed = FloatValue("Speed", 1.4f, 1f, 2f)
    private val ticks = FloatValue("Ticks", 10f, 1f, 50f)
    private val ticks2 = FloatValue("SpeedTicks", 10f, 1f, 50f)
    private val AutoJump = BoolValue("AutoJump", false)

    private var tickCounter = 0
    private var phase = 1

    override fun onEnable() {

        phase=1
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        tickCounter++
        when (phase) {
            0 -> {
                mc.timer.timerSpeed = speed.get()
                if (tickCounter >= ticks2.get()) {
                    tickCounter = 0
                    phase = 1



                    if(AutoJump.get()){
                        simulateJump()

                    }
                }
            }
            1 -> {
                mc.timer.timerSpeed = 1F
                if (tickCounter >= ticks.get()) {
                    tickCounter = 0
                    phase = 0
                }
            }
        }
    }


    private fun simulateJump() {
        val jumpKey = mc.gameSettings.keyBindJump
        KeyBinding.setKeyBindState(jumpKey.keyCode, true) // Press the jump key
        KeyBinding.onTick(jumpKey.keyCode) // Process the key press
    }

    override fun onDisable() {
        mc.timer.timerSpeed = 1.0f // Reset the timer when the module is disabled
        resetJumpKey()
    }

    private fun resetJumpKey() {
        val jumpKey = mc.gameSettings.keyBindJump
        KeyBinding.setKeyBindState(jumpKey.keyCode, false) // Release the jump key
    }
}