package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.client.Minecraft

@ModuleInfo(name = "IntaveTower", category = ModuleCategory.MOVEMENT)
class IntaveTower : Module() {
    private val TowerSpeed = FloatValue("TowerSpeed", 2F, 1F, 5F)
    private val HighCheck = FloatValue("HighCheck", 0.2F, 0F, 1F)
    private val NoXZ = BoolValue("NoXZ", true)
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val player = mc.thePlayer

        if (player != null) {
            if (!player.onGround && player.motionY > HighCheck.get()) {
                if (NoXZ.get()){
                    mc.thePlayer.motionX= 0.0
                    mc.thePlayer.motionZ= 0.0
                }
                mc.timer.timerSpeed = TowerSpeed.get() // 这里调整跳跃时的速度
            } else {
                mc.timer.timerSpeed = 1.0f // 这里恢复正常速度
            }
        }
    }
}
