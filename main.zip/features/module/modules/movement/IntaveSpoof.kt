package net.ccbluex.liquidbounce.features.module.modules.movement


import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.client.Minecraft
import net.minecraft.client.settings.KeyBinding
import net.minecraft.util.ChatComponentText
import net.minecraftforge.common.MinecraftForge
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent
import net.minecraftforge.fml.common.gameevent.TickEvent

@ModuleInfo(name = "IntaveSpoof", category = ModuleCategory.MOVEMENT)
class IntaveSpoof : Module() {
    private val Debug = BoolValue("Debug", true)
    private val Speed = FloatValue("Speed", 0.09f, 0f, 0.2f)
    private var lastX: Double = 0.0
    private var lastY: Double = 0.0
    private var lastZ: Double = 0.0

    override fun onEnable() {
        MinecraftForge.EVENT_BUS.register(this)
        val player = Minecraft.getMinecraft().thePlayer
        if (player != null) {
            lastX = player.posX
            lastY = player.posY
            lastZ = player.posZ
        }
    }

    override fun onDisable() {
        MinecraftForge.EVENT_BUS.unregister(this)
    }

    @SubscribeEvent
    fun onPlayerTick(event: TickEvent.PlayerTickEvent) {
        val player = event.player
        if (player != null) {
            val currentX = player.posX
            val currentY = player.posY
            val currentZ = player.posZ

            val isMoving = currentX != lastX || currentY != lastY || currentZ != lastZ

            if (isMoving) {
                if (mc.thePlayer != null && mc.gameSettings.keyBindForward.isKeyDown) {
                    MovementUtils.setMotion(Speed.get().toDouble())
                    if (Debug.get()) {
                        mc.ingameGUI.chatGUI.printChatMessage(ChatComponentText("Player is moving | isKeyDown (Forward)"))
                    }
                }

            } else {

            }

            lastX = currentX
            lastY = currentY
            lastZ = currentZ
        }
    }
}
