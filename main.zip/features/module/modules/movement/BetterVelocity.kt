package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import net.minecraft.network.play.client.C07PacketPlayerDigging
import net.minecraft.network.play.client.C0FPacketConfirmTransaction
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import kotlin.math.cos
import kotlin.math.sin


@ModuleInfo(name = "BetterVelocity", category = ModuleCategory.COMBAT)
class BetterVelocity : Module() {
    var jump = false
    private val modeValue = ListValue("Mode", arrayOf("Custom", "Test","Intave","IntaveReduce","MoveReduce","JumpNoXZ"), "Custom")
    private val MaxHurtTime = IntegerValue("MaxHurtTime", 1, 1, 10).displayable { modeValue.get() == "Custom" }
    private val MinHurtTime = IntegerValue("MinHurtTime", 1, 1, 10).displayable { modeValue.get() == "Custom" }
    private val motionX = FloatValue("MotionX", 0.44F, 0F, 1F).displayable { modeValue.get() == "Custom" }
    private val motionZ = FloatValue("MotionZ", 0.44F, 0F, 1F).displayable { modeValue.get() == "Custom" }
    private val AirMotionX = FloatValue("AirMotionX", 0.44F, 0F, 1F).displayable { modeValue.get() == "Custom" }
    private val AirMotionZ = FloatValue("AirMotionZ", 0.44F, 0F, 1F).displayable { modeValue.get() == "Custom" }
    private val C03 = BoolValue("C03", false)
    private val C0F = BoolValue("C0F", false)
    var yreducer = BoolValue("YReducer", true).displayable { modeValue.get() == "Test" }
    var lreverse = BoolValue("LreverseW", true).displayable { modeValue.get() == "Test" }
    var yreduce = FloatValue("YReduce", 0.05F, 0.0F, 2F).displayable { modeValue.get() == "Test" }
    private val JumpRest = BoolValue("JumpReset", false)
    private val NoGUI = BoolValue("NoGUI", true)
    var hurt = false
    var BoolTag = false
    var cancel = false
    var tick = 0
    override fun onDisable() {
        hurt = false
        jump = false
        BoolTag = false
        cancel = false
        tick = 0
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (hurt&&C03.get() && packet is C03PacketPlayer) {
            event.cancelEvent()
        }


        if (cancel&&packet is S08PacketPlayerPosLook){
            event.cancelEvent()
        }
        if (cancel&&packet is C03PacketPlayer){
            event.cancelEvent()
        }
        if (cancel&&packet is C0FPacketConfirmTransaction){
            event.cancelEvent()
        }
        if (cancel&&packet is C04PacketPlayerPosition){
            event.cancelEvent()
        }
        if (cancel&&packet is C07PacketPlayerDigging){
            event.cancelEvent()
        }

        if (hurt&&C0F.get() && packet is C0FPacketConfirmTransaction) {
            event.cancelEvent()
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (!NoGUI.get() || mc.currentScreen == null) {
        if (mc.thePlayer.hurtTime >= 1&&mc.thePlayer.onGround&&JumpRest.get()) {
            mc.gameSettings.keyBindJump.pressed = true
            jump = true
        }else if (jump){
            mc.gameSettings.keyBindJump.pressed = false
            jump = false
        }

        if (modeValue.get() == "Test") {
            if (mc.objectMouseOver == null) return
            if (mc.thePlayer.hurtTime <= 6 && mc.thePlayer.isSwingInProgress && mc.thePlayer.hurtTime > 0) {
                if (lreverse.get() && mc.gameSettings.keyBindJump.pressed) {
                    mc.thePlayer.motionX = -sin(Math.toRadians((mc.thePlayer.rotationYaw.toDouble()))) * 0.02f
                    mc.thePlayer.motionZ = cos(Math.toRadians((mc.thePlayer.rotationYaw.toDouble()))) * 0.02f
                }
                if (yreducer.get() && mc.gameSettings.keyBindJump.pressed) {
                    mc.thePlayer.motionY *= 1 - yreduce.get()
                }
            }

        }
        if (modeValue.get() == "Custom"&&mc.thePlayer.hurtTime in MinHurtTime.get()..MaxHurtTime.get() && mc.thePlayer.isSwingInProgress) {
            hurt = true
            if ((mc.thePlayer.onGround)) {
                mc.thePlayer.motionX *= motionX.get()
                mc.thePlayer.motionZ *= motionZ.get()
                BoolTag = true
            } else {
                mc.thePlayer.motionX *= AirMotionX.get()
                mc.thePlayer.motionZ *= AirMotionZ.get()
                BoolTag = false
            }
        }else{
            hurt = false
            BoolTag = false
        }


        if (modeValue.get() == "Intave"&&mc.thePlayer.hurtTime in 6..9 && mc.thePlayer.isSwingInProgress) {
            if (mc.thePlayer.onGround) {
                mc.thePlayer.motionX *= 0.66
                mc.thePlayer.motionZ *= 0.66
                BoolTag = true
            } else {
                mc.thePlayer.motionX *= 1F
                mc.thePlayer.motionZ *= 1F
                BoolTag = false
            }
        }else{
            BoolTag = false
        }

        if (modeValue.get() == "IntaveReduce"&&mc.thePlayer.hurtTime in 8..10 && mc.thePlayer.isSwingInProgress) {
            if (mc.thePlayer.onGround) {
                BoolTag = true
                mc.thePlayer.motionX *= 0.66
                mc.thePlayer.motionZ *= 0.66
            }
        }else{
            BoolTag = false
        }
            if (modeValue.get() == "MoveReduce"&&mc.thePlayer.hurtTime in 8..10 && mc.thePlayer.isSwingInProgress&&mc.gameSettings.keyBindForward.pressed&&!mc.gameSettings.keyBindSneak.pressed) {
                    BoolTag = true
                    mc.thePlayer.motionX *= 0.99888F
                    mc.thePlayer.motionZ *= 0.99888F
            }else{
                BoolTag = false
            }
            if (modeValue.get() == "JumpNoXZ"&&mc.thePlayer.hurtTime in 7..10 &&mc.gameSettings.keyBindJump.pressed&&!mc.thePlayer.onGround) {
                BoolTag = true
                mc.thePlayer.motionX *= 0
                mc.thePlayer.motionZ *= 0
            }else{
                BoolTag = false
            }

    }
    }
    override val tag: String
        get() = modeValue.get() +" | "+ mc.thePlayer.hurtTime +" - "+BoolTag
}