package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.*
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import net.minecraft.network.play.server.S12PacketEntityVelocity
import net.minecraft.network.play.server.S14PacketEntity.S15PacketEntityRelMove
import net.minecraft.network.play.server.S14PacketEntity.S17PacketEntityLookMove
import net.minecraft.network.play.server.S30PacketWindowItems
import net.minecraft.network.play.server.S40PacketDisconnect
import net.minecraft.network.status.client.C00PacketServerQuery
import net.minecraft.network.status.client.C01PacketPing
import org.lwjgl.input.Keyboard

@ModuleInfo(name = "CustomHop", category = ModuleCategory.MOVEMENT)
class CustomHop : Module() {
    private val modeValue = ListValue("Mode", arrayOf("CancelPackets"), "CancelPackets")
    private var motionX = 0.0
    private var motionY = 0.0
    private var motionZ = 0.0
    private var x = 0.0
    private var y = 0.0
    private var z = 0.0
    private val OnAirMotionY = BoolValue("OnAirMotionY", false)
    private val OnAirMotionYValue = FloatValue("OnAirMotionY-Value", -0.42f, -0.5f, 0.5f)
    private val OnAirMotionYTicks = IntegerValue("OnAirMotionY-Ticks", 5, 0, 20)

    private val OnAirTimer = BoolValue("OnAirTimer", false)
    private val OnAirTimerValue = FloatValue("OnAirTimer-Value", 2f, 0.1f, 10f)
    private val OnAirTimerTicks = IntegerValue("OnAirTimer-Ticks", 5, 0, 20)

    private val OnAirSpeed = BoolValue("OnAirSpeed", false)
    private val OnAirSpeedValue = FloatValue("OnAirSpeed-Value", 2f, 0.1f, 10f)


    private val OnGroundMotionY = BoolValue("OnGroundMotionY", false)
    private val OnGroundMotionYValue = FloatValue("OnGroundMotionY-Value", -0.42f, -0.5f, 0.5f)
    private val OnGroundMotionYTicks = IntegerValue("OnGroundMotionY-Ticks", 5, 0, 20)

    private val OnGroundTimer = BoolValue("OnGroundTimer", false)
    private val OnGroundTimerValue = FloatValue("OnGroundTimer-Value", 1f, 0.1f, 10f)
    private val OnGroundTimerTicks = IntegerValue("OnGroundTimer-Ticks", 5, 0, 20)

    private val OnGroundSpeed = BoolValue("OnGroundSpeed", false)
    private val OnGroundSpeedValue = FloatValue("OnGroundSpeed-Value", 1f, 0.1f, 10f)

    private val IntaveResetVL = BoolValue("Intave", true)
    private val FreezeOnEnable = BoolValue("FreezeOnEnable", true)
    private val MotionYJump = BoolValue("MotionYJump", false)

    var Freeze = 0
    var OnAirMotionYTicksN = 0
    var OnAirTimerTicksN = 0
    var OnGroundMotionYTicksN = 0
    var OnGroundTimerTicksN =0
    override fun onDisable() {
        mc.timer.timerSpeed = 1F

    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (FreezeOnEnable.get()&&event.packet is S08PacketPlayerPosLook){
                x = event.packet.x
                y = event.packet.y
                z = event.packet.z
                motionX = 0.0
                motionY = 0.0
                motionZ = 0.0
        }
        if (IntaveResetVL.get()){
        val packet = event.packet

        if (modeValue.get()=="CancelPackets"&& packet is C0FPacketConfirmTransaction) {
            event.cancelEvent()
        }

        if (modeValue.get()=="CancelPackets"&& packet is C03PacketPlayer && !(packet is C03PacketPlayer.C04PacketPlayerPosition || packet is C03PacketPlayer.C05PacketPlayerLook || packet is C03PacketPlayer.C06PacketPlayerPosLook)) {
            event.cancelEvent()
        }
        }
     }

    override fun onEnable() {
        OnAirMotionYTicksN = 0
        OnAirTimerTicksN = 0
        Freeze = 0
        x = mc.thePlayer.posX
        y = mc.thePlayer.posY
        z = mc.thePlayer.posZ
        motionX = mc.thePlayer.motionX
        motionY = mc.thePlayer.motionY
        motionZ = mc.thePlayer.motionZ
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (FreezeOnEnable.get()){
           if (Freeze < 30) {
               Freeze++
               mc.thePlayer.motionX = 0.0
               mc.thePlayer.motionY = 0.0
               mc.thePlayer.motionZ = 0.0
               mc.thePlayer.setPositionAndRotation(x, y, z, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch)
           }else    {

           }
        }
        if (MotionYJump.get()&&mc.thePlayer.onGround){
            mc.thePlayer.motionY = 0.42
        }
        if (OnAirMotionY.get()&&!mc.thePlayer.onGround){
            if (OnAirMotionYTicksN<=OnAirMotionYTicks.get()){
                OnAirMotionYTicksN++
            }else {
                mc.thePlayer.motionY = OnAirMotionYValue.get().toDouble()
                OnAirMotionYTicksN = 0
            }
        }
        if (OnAirTimer.get()&&!mc.thePlayer.onGround){
            if (OnAirTimerTicksN<=OnAirTimerTicks.get()){
                OnAirTimerTicksN++
                mc.timer.timerSpeed = 1F
            }else {
                mc.timer.timerSpeed = OnAirTimerValue.get()
                OnAirTimerTicksN = 0
            }
        }
        if (OnAirSpeed.get()&&!mc.thePlayer.onGround){
            MovementUtils.setMotion(OnAirSpeedValue.get().toDouble())
        }

        if (OnGroundMotionY.get()&&mc.thePlayer.onGround){
            if (OnGroundMotionYTicksN<=OnGroundMotionYTicks.get()){
                OnGroundMotionYTicksN++
            }else {
                mc.thePlayer.motionY = OnGroundMotionYValue.get().toDouble()
                OnGroundMotionYTicksN= 0
            }
        }
        if (OnGroundTimer.get()&&mc.thePlayer.onGround) {
            if (OnGroundTimerTicksN <= OnGroundTimerTicks.get()) {
                OnGroundTimerTicksN++
                mc.timer.timerSpeed = 1F
            } else {
                mc.timer.timerSpeed = OnGroundTimerValue.get()
                OnGroundTimerTicksN =0
            }
        }
        if (OnGroundSpeed.get()&&!mc.thePlayer.onGround){
            MovementUtils.setMotion(OnGroundSpeedValue.get().toDouble())
        }
    }
    override val tag: String
        get() = modeValue.get()
}