package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.TimeUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.settings.KeyBinding
import net.minecraft.init.Items
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.server.S08PacketPlayerPosLook

@ModuleInfo(name = "IntaveFireballFlight", category = ModuleCategory.MOVEMENT)
class IntaveFireballFlight : Module() {
    private val FlightMode = ListValue("Mode", arrayOf("Hight", "Long", "All"), "Hight")
    private val motionxz = FloatValue("WhenFlightModeIsLongThePlayerMotionXZSpeed", 0.15F, 0F, 1F)
    private val motiony = BoolValue("motionY", false)
    private val motionyvalue = FloatValue("motionY-Value", 0.15F, 0F, 1F)
    private val Freeze = BoolValue("Freeze", false)
    private var rightDelay = TimeUtils.randomClickDelay(40,40)
    private var rightLastSwing = 0L
    override fun onEnable() {

    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (FlightMode.equals("Hight")&&mc.gameSettings.keyBindJump.isKeyDown&&!mc.gameSettings.keyBindForward.isKeyDown&&!mc.gameSettings.keyBindBack.isKeyDown&&!mc.thePlayer.onGround){
            val player = mc.thePlayer ?: return
            for (slot in 0 until 8) {
                val stackInSlot = player.inventory.getStackInSlot(slot)

                if (stackInSlot != null && stackInSlot.item == Items.fire_charge) {

                    player.inventory.currentItem = slot
                    if (!mc.thePlayer.isUsingItem&&
                        System.currentTimeMillis() - rightLastSwing >= rightDelay) {
                        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.keyCode)
                        rightLastSwing = System.currentTimeMillis()
                        rightDelay = TimeUtils.randomClickDelay(40, 40)
                    }
                    if (motiony.get()&&mc.thePlayer.hurtTime>0){
                        mc.thePlayer.motionY=motionyvalue.get().toDouble()
                    }
                    break
                }
            }
    }
        if (FlightMode.equals("All")){
            val player = mc.thePlayer ?: return
            for (slot in 0 until 8) {
                val stackInSlot = player.inventory.getStackInSlot(slot)

                if (stackInSlot != null && stackInSlot.item == Items.fire_charge) {

                    player.inventory.currentItem = slot
                    if (!mc.thePlayer.isUsingItem&&
                        System.currentTimeMillis() - rightLastSwing >= rightDelay) {
                        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.keyCode)
                        rightLastSwing = System.currentTimeMillis()
                        rightDelay = TimeUtils.randomClickDelay(40, 40)
                    }
                    if (motiony.get()&&mc.thePlayer.hurtTime>0){
                        mc.thePlayer.motionY=motionyvalue.get().toDouble()
                    }
                    break

                }else  {
                }
            }
        }
        if (FlightMode.equals("Long")&&mc.gameSettings.keyBindJump.isKeyDown&&mc.gameSettings.keyBindForward.isKeyDown){
            val player = mc.thePlayer ?: return
            for (slot in 0 until 8) {
                val stackInSlot = player.inventory.getStackInSlot(slot)

                if (stackInSlot != null && stackInSlot.item == Items.fire_charge) {

                    player.inventory.currentItem = slot
                    if (!mc.thePlayer.isUsingItem&&
                        System.currentTimeMillis() - rightLastSwing >= rightDelay) {
                        KeyBinding.onTick(mc.gameSettings.keyBindUseItem.keyCode)
                        rightLastSwing = System.currentTimeMillis()
                        rightDelay = TimeUtils.randomClickDelay(40, 40)
                    }
                    if (motiony.get()&&mc.thePlayer.hurtTime>0){
                        mc.thePlayer.motionY=motionyvalue.get().toDouble()
                    }
                    break
                }}}
    }
    }
