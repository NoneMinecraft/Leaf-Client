//leaf client
//code by None

package net.ccbluex.liquidbounce.features.module.modules.movement
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.MainLib.RightClick
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.utils.timer.TimeUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.settings.GameSettings
import net.minecraft.client.settings.KeyBinding
import net.minecraft.init.Blocks
import net.minecraft.item.ItemBlock
import net.minecraft.util.BlockPos

@ModuleInfo(name = "LegitScaffold", category = ModuleCategory.MOVEMENT)
class LegitScaffold : Module() {
    private var tickCounter = 0
    private var phase = 1
    var n = 0
    var n2 = 0
    var wasset = false
    private val maxCPSValue: IntegerValue = object : IntegerValue("MaxCPS", 8, 1, 40) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val minCPS = minCPSValue.get()
            if (minCPS > newValue) {
                set(minCPS)
            }
        }
    }
    private val minCPSValue: IntegerValue = object : IntegerValue("MinCPS", 5, 1, 40) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val maxCPS = maxCPSValue.get()
            if (maxCPS < newValue) {
                set(maxCPS)
            }
        }
    }
    private val rightValue = BoolValue("RightClick", true)
    private val rightBlockOnlyValue = BoolValue("RightClickBlockOnly", false)
    var fixv = 0.0F
    private var tickCounter2 = 0
    private var phase2 = 1
    private val Pitch = FloatValue("Pitch", 79F, 0F, 180F)
    private val Yaw = BoolValue("Yaw", true)
    private val YawV = FloatValue("Yaw-Value", 180F, -180F, 180F)
    private val TurnAroundOnEnable = BoolValue("TurnAroundOnEnable", false)
    private val TurnAroundOnEnableValue = FloatValue("TurnAroundOnEnable-Value", 180F, 0F, 180F)
    private val Jitter = BoolValue("Jitter", false)
    private val JitterTicks = FloatValue("Jitter-Ticks", 2F, 1F, 20F)
    private val JitterValue = FloatValue("Jitter-Value", 2F, 0.1F, 20F)
    private val Timer = BoolValue("Timer", false)
    private val TimerValue = FloatValue("Timer-Speed", 1F, 0.1F, 20F)
    private val SafeWalk = BoolValue("SafeWalk", true)
    private val airSafeValue = BoolValue("SafeWalk-AirSafe", false)
    private val onlyVoidValue = BoolValue("SafeWalk-OnlyPredictVoid", false)
    private val AirPitch = BoolValue("AirPitch", false)
    private val AirPitchValue = FloatValue("AirPitch-Value", 80F, -180F, 180F)
    private val TurnAround = BoolValue("TurnAround", false)
    private val TurnAroundTicksWhen1 = FloatValue("TurnAroundTicksWhenPhase1", 5F, 0F, 20F)
    private val TurnAroundTicksWhen2 = FloatValue("TurnAroundTicksWhenPhase2", 5F, 0F, 20F)
    private val TurnAroundValue = FloatValue("TurnAroundWhenPhase1-Value", 180F, -180F, 180F)
    private val TurnAroundValue2 = FloatValue("TurnAroundWhenPhase2-Value", 180F, -180F, 180F)
    private val TurnAroundOnAir = BoolValue("TurnAroundOnAir", true)
    private val ResetPhaseOnGround = BoolValue("ResetPhaseOnGround", false)
    private val AutoJump = BoolValue("AutoJump", false)
    private val Eagle = BoolValue("Eagle", false)
    private val RotationFix = BoolValue("FixedPlayerPitchAnomaliesByReducingPlayerPitchWheThPlayerAttemptedToAim", true)
    private val RotationFixValue = FloatValue("RotationFix-Value", 10F, 0F, 30F)
    private val ReducePitchOnAir = BoolValue("ReducePitchOnAir", false)
    private val ReducePitchOnAirSinglePitchReductionValue = FloatValue("ReducePitchOnAir-SinglePitchReduction-Value", 10F, -50F, 50F)
    private val ReducePitchOnAirSinglePitchReductionTicks = FloatValue("ReducePitchOnAir-SinglePitchReduction-Ticks", 10F, -50F, 50F)
    private val WhenDisabledTheCounterReducePitchOnAirSinglePitchReductioN2ModuleIsInitialisedValue = FloatValue("WhenDisabled-TheCounterReducePitchOnAirSinglePitchReductio-N2ModuleIs-InitialisedValue", 0F, 0F, 1F)
    private val WhenDisabledTheCounterReducePitchOnAirSinglePitchReductioN1ModuleIsInitialisedValue = FloatValue("WhenDisabled-TheCounterReducePitchOnAirSinglePitchReductio-N1ModuleIs-InitialisedValue", 0F, 0F, 1F)
    override fun onEnable() {
        wasset=false
        n= 0
        if (TurnAroundOnEnable.get()){
            mc.thePlayer.rotationYaw += TurnAroundOnEnableValue.get()
        }
        if (mc.thePlayer == null) {
            return
        }
        if (!GameSettings.isKeyDown(mc.gameSettings.keyBindSneak)) {
            mc.gameSettings.keyBindSneak.pressed = false


        }
    }
    private var rightDelay = TimeUtils.randomClickDelay(minCPSValue.get(), maxCPSValue.get())
    private var rightLastSwing = 0L
    @EventTarget
    fun onRender(event: Render3DEvent) {
        if (!mc.thePlayer.isUsingItem && rightValue.get() &&
            System.currentTimeMillis() - rightLastSwing >= rightDelay&& rightValue.get()) {
            KeyBinding.onTick(mc.gameSettings.keyBindUseItem.keyCode)
            rightLastSwing = System.currentTimeMillis()
            rightDelay = TimeUtils.randomClickDelay(minCPSValue.get(), maxCPSValue.get())
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {

        if (RotationFix.get()){
            fixv = RotationFixValue.get()
        }else{fixv=0F}

        if (Eagle.get()){
            mc.gameSettings.keyBindSneak.pressed =
                mc.theWorld.getBlockState(BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1.0, mc.thePlayer.posZ)).block == Blocks.air
        }
        if (AutoJump.get()&&mc.thePlayer.onGround){
          mc.thePlayer.motionY = 0.42
        }
        if(Timer.get()){
            mc.timer.timerSpeed=TimerValue.get()
        }
        else{
            mc.timer.timerSpeed=1F
        }
        if (AirPitch.get()&&!mc.thePlayer.onGround) {
            if (ReducePitchOnAir.get()) {
                if (!wasset) {
                    mc.thePlayer.rotationPitch = AirPitchValue.get()
                    wasset = true
                } else if (mc.thePlayer.rotationPitch < 90-fixv) {
                    if (n2 <= ReducePitchOnAirSinglePitchReductionTicks.get().toInt()) {
                        n2++

                    } else {
                        n2 = 0
                        mc.thePlayer.rotationPitch += ReducePitchOnAirSinglePitchReductionValue.get()
                    }
                }else{
                    wasset = false
                }
            } else {
                mc.thePlayer.rotationPitch = AirPitchValue.get()
            }
        } else{
        mc.thePlayer.rotationPitch = Pitch.get()
        }
        if(Yaw.get()){
            mc.thePlayer.rotationYaw += YawV.get()
        }
        if (TurnAround.get()){
            tickCounter2++
            when (phase2) {
                0 -> {
                    if (tickCounter2 >= TurnAroundTicksWhen1.get()) {
                        tickCounter2 = 0
                        phase2 = 1
                        if (TurnAroundOnAir.get()){
                        if (!mc.thePlayer.onGround) {
                            mc.thePlayer.rotationYaw+=TurnAroundValue.get()
                        }else if (ResetPhaseOnGround.get()){
                            phase2=1
                        }
                        }
                        else{
                            mc.thePlayer.rotationYaw+=TurnAroundValue.get()
                        }
                    }
                }
                1 -> {
                    if (tickCounter2 >= TurnAroundTicksWhen2.get()) {
                        tickCounter2 = 0
                        phase2 = 0
                        if (TurnAroundOnAir.get()){
                            if (!mc.thePlayer.onGround) {
                                mc.thePlayer.rotationYaw+=TurnAroundValue2.get()
                            }else if (ResetPhaseOnGround.get()){
                                phase2=1
                            }
                        }
                        else{
                            mc.thePlayer.rotationYaw+=TurnAroundValue2.get()
                        }
                    }
                }}
        }

        if (Jitter.get()){
            tickCounter++
            when (phase) {
                0 -> {
                    if (tickCounter >= JitterTicks.get()) {
                        tickCounter = 0
                        phase = 1
                        mc.thePlayer.rotationYaw += JitterValue.get()
                    }
                }
                1 -> {
                    if (tickCounter >= JitterTicks.get()) {
                        tickCounter = 0
                        phase = 0
                        mc.thePlayer.rotationYaw -= JitterValue.get()
                    }
                }
            }
        }


    }


    @EventTarget
    fun onMove(event: MoveEvent) {
        if (SafeWalk.get()){
            if (onlyVoidValue.get() && !checkVoid()) {
                return
            } else {
                if (airSafeValue.get() || mc.thePlayer.onGround) {

                    event.isSafeWalk = true

                }else{
                    event.isSafeWalk = false

                }
            }
        }
    }

    private fun checkVoid(): Boolean {
        var i = (-(mc.thePlayer.posY-1.4857625)).toInt()
        var dangerous = true
        while (i <= 0) {
            dangerous = mc.theWorld.getCollisionBoxes(mc.thePlayer.entityBoundingBox.offset(mc.thePlayer.motionX * 1.4, i.toDouble(), mc.thePlayer.motionZ * 1.4)).isEmpty()
            i++
            if (!dangerous) break
        }
        return dangerous
    }
    override fun onDisable() {
        mc.gameSettings.keyBindRight.isPressed
        phase=1
        phase2=1
        mc.timer.timerSpeed=1F
        n= WhenDisabledTheCounterReducePitchOnAirSinglePitchReductioN1ModuleIsInitialisedValue.get().toInt()
        n2 = WhenDisabledTheCounterReducePitchOnAirSinglePitchReductioN2ModuleIsInitialisedValue.get().toInt()
        wasset = false
    }
}