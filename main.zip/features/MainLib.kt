/*
Leaf Client
Code By None
*/

package net.ccbluex.liquidbounce.features

import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.mc
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.init.Items
import net.minecraft.item.Item
import net.minecraft.network.play.client.C01PacketChatMessage
import net.minecraft.util.ChatComponentText
import net.minecraft.util.MathHelper
import java.awt.geom.Point2D

var Pitch = 0.0F

object MainLib {
    fun findItem(item: Item?): Int {
        for (i in 1 until mc.thePlayer.inventory.mainInventory.size) {
            val stack = mc.thePlayer.inventory.getStackInSlot(i)
            if (stack != null && stack.item == item) {
                return i

            }
        }
        return -1
    }
    fun findSword(): Int {
        for (i in 1 until mc.thePlayer.inventory.mainInventory.size) {
            val stack = mc.thePlayer.inventory.getStackInSlot(i)
            if (stack != null &&( stack.item == Items.wooden_sword ||stack.item == Items.stone_sword  ||stack.item == Items.iron_sword ||stack.item == Items.golden_sword  ||stack.item == Items.diamond_sword )) {
                return i

            }
        }
        return -1
    }
    fun filteEntityPlayer(filter:Boolean , firstOrNull:Boolean): EntityPlayer? {
        return mc.theWorld.playerEntities.filterIsInstance<EntityPlayer>()
            .filter {filter}
            .firstOrNull{firstOrNull}
    }

    fun FindItems(items: Items): Int {
        for (i in 1 until mc.thePlayer.inventory.mainInventory.size) {
            val stack = mc.thePlayer.inventory.getStackInSlot(i)
            if (stack != null && stack.item == items) {
                return i

            }
        }
        return -1
    }

    fun strictStrafeX(yaw:Float? , x:Double , z:Double):Double{
        val radianYaw = Math.toRadians(yaw!!.toDouble()).toFloat()
        val moveForward = MinecraftInstance.mc.thePlayer.movementInput.moveForward
        val strafeSpeed = MinecraftInstance.mc.thePlayer.movementInput.moveStrafe
        val newX = (-MathHelper.sin(radianYaw) * moveForward + MathHelper.cos(radianYaw) * strafeSpeed).toDouble()
        val speed = Math.sqrt(x * x + z * z)
        return newX * speed
    }
    fun strictStrafeZ(yaw:Float? , x:Double , z:Double):Double{
        val radianYaw = Math.toRadians(yaw!!.toDouble()).toFloat()
        val moveForward = MinecraftInstance.mc.thePlayer.movementInput.moveForward
        val strafeSpeed = MinecraftInstance.mc.thePlayer.movementInput.moveStrafe
        val newZ = (MathHelper.cos(radianYaw) * moveForward + MathHelper.sin(radianYaw) * strafeSpeed).toDouble()
        val speed = Math.sqrt(x * x + z * z)
        return newZ * speed
    }


    fun checkVoid(): Boolean {
        var i = (-(mc.thePlayer.posY - 1.4857625)).toInt()
        var dangerous = true
        while (i <= 0) {
            dangerous = mc.theWorld.getCollisionBoxes(
                mc.thePlayer.entityBoundingBox.offset(
                    mc.thePlayer.motionX * 1.4,
                    i.toDouble(),
                    mc.thePlayer.motionZ * 1.4
                )
            ).isEmpty()
            i++
            if (!dangerous) break
        }
        return dangerous
    }

    fun RightClick(pressed:Boolean){
    mc.gameSettings.keyBindUseItem.pressed = pressed
    }
    fun LeftClick(pressed:Boolean){
        mc.gameSettings.keyBindUseItem.pressed = pressed
    }
    fun Jump(pressed:Boolean){
        mc.gameSettings.keyBindJump.pressed = pressed
    }
    fun Sneak(pressed:Boolean){
        mc.gameSettings.keyBindSneak.pressed = pressed
    }
    fun Chat(message:String){
        mc.thePlayer.sendQueue.addToSendQueue(C01PacketChatMessage())
    }
    fun ChatPrint(message:String){
    mc.ingameGUI.chatGUI.printChatMessage(ChatComponentText(message))
}

}
