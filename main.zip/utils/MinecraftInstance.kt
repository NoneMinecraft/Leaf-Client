package net.ccbluex.liquidbounce.utils

import net.minecraft.client.Minecraft

val mc = Minecraft.getMinecraft()