/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.utils3

import net.ccbluex.liquidbounce.utils.MinecraftInstance

object TransferUtils : MinecraftInstance() {
    var silentConfirm = false
    var noMotionSet = false
}