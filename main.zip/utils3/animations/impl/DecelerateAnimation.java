package net.ccbluex.liquidbounce.utils3.animations.impl;


import net.ccbluex.liquidbounce.utils3.animations.Animation;
import net.ccbluex.liquidbounce.utils3.animations.Direction;

public class DecelerateAnimation extends Animation {

    public DecelerateAnimation(int ms, double endPoint) {
        super(ms, endPoint);
    }

    protected double getEquation(double x) {
        return 1 - ((x - 1) * (x - 1));
    }
}
