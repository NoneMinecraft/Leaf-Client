package net.ccbluex.liquidbounce.utils8.render

import net.minecraft.item.ItemStack

object FakeItemRender {
    var fakeItem: Int = -1
}