/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.utils8

object URLComponent {
    const val WEBSITE = "https://fdpinfo.github.io/next"
    const val STATUS = "$WEBSITE/database/data.txt"
    const val CHANGELOGS = "$WEBSITE/database/changelogs.txt"
    const val BUGS = "$WEBSITE/database/bugs.txt"
    const val DONORS = "$WEBSITE/donors/"
    const val PICTURES = "$WEBSITE/pictures/"
}