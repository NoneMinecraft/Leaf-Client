/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/SkidderMC/FDPClient/
 */
package net.ccbluex.liquidbounce.utils8.timing

import net.ccbluex.liquidbounce.event8.EventTarget
import net.ccbluex.liquidbounce.event8.GameTickEvent
import net.ccbluex.liquidbounce.event8.Listenable
import net.ccbluex.liquidbounce.utils8.ClientUtils
import net.ccbluex.liquidbounce.utils8.MinecraftInstance

object WaitTickUtils : MinecraftInstance(), Listenable {

    private val scheduledActions = mutableListOf<ScheduledAction>()

    fun scheduleTicks(ticks: Int, action: () -> Unit) {
        scheduledActions.add(ScheduledAction(ClientUtils.runTimeTicks + ticks, action))
    }

    @EventTarget(priority = -1)
    fun onTick(event: GameTickEvent) {
        val currentTick = ClientUtils.runTimeTicks
        val iterator = scheduledActions.iterator()

        while (iterator.hasNext()) {
            val scheduledAction = iterator.next()
            if (currentTick >= scheduledAction.ticks) {
                scheduledAction.action.invoke()
                iterator.remove()
            }
        }
    }

    private data class ScheduledAction(val ticks: Int, val action: () -> Unit)

    override fun handleEvents() = true
}