package net.ccbluex.liquidbounce.utils4.misc.sound;


import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.utils4.FileUtils
import java.io.File

class TipSoundManager {
    var enableSound: TipSoundPlayer
    var disableSound: TipSoundPlayer
    var popSound: TipSoundPlayer
    var swingSound: TipSoundPlayer

    init {
        val enableSoundFile = File(LiquidBounce.fileManager.soundsDir, "enable.wav")
        val disableSoundFile = File(LiquidBounce.fileManager.soundsDir, "disable.wav")
        val popSoundFile = File(LiquidBounce.fileManager.soundsDir, "pop.wav")
        val swingSoundFile = File(LiquidBounce.fileManager.soundsDir, "swing.wav")

        if (!enableSoundFile.exists())
            FileUtils.unpackFile(enableSoundFile, "assets/minecraft/client/sound/enable.wav")
        if (!disableSoundFile.exists())
            FileUtils.unpackFile(disableSoundFile, "assets/minecraft/client/sound/disable.wav")
        if (!popSoundFile.exists())
            FileUtils.unpackFile(popSoundFile, "assets/minecraft/client/sound/pop.wav")
        if (!swingSoundFile.exists())
            FileUtils.unpackFile(swingSoundFile, "assets/minecraft/client/sound/swing.wav")

        enableSound = TipSoundPlayer(enableSoundFile)
        disableSound = TipSoundPlayer(disableSoundFile)
        popSound = TipSoundPlayer(popSoundFile)
        swingSound = TipSoundPlayer(swingSoundFile)
    }
}