package net.ccbluex.liquidbounce.utils4;

object TransferUtils : MinecraftInstance() {
    var noMotionSet = false
}