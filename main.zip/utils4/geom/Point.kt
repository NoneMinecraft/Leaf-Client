package net.ccbluex.liquidbounce.utils4.geom;

class Point(var x: Float, var y: Float)