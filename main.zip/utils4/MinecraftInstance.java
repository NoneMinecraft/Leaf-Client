package net.ccbluex.liquidbounce.utils4;

import net.minecraft.client.Minecraft;

/**
 * The type Minecraft instance.
 */
public class MinecraftInstance {
    /**
     * The constant mc.
     */
    public static final Minecraft mc = Minecraft.getMinecraft();
}
